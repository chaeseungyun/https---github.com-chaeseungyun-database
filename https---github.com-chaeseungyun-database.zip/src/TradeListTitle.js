import './TradeListTitle.css';

export default function TradeListTitle() {
  return (
    <div className='trade-list-container'>
      <span>1</span>
      <span style={{width: '180px'}}>2</span>
      <span>3</span>
      <span>4</span>
      <span>5</span>
      <span>6</span>
    </div>
  )
}