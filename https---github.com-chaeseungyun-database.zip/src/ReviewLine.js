import './Review.css';

export default function ReviewLine() {
  return (
    <div className='review-box'>
        <span>이새람</span>
        <span className='review-content'>content</span>
        <span>x점</span>
        <span>날짜</span>
    </div>
  )
}