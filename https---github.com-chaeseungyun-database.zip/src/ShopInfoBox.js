import "./ShopInfoBox.css";

export default function ShopInfoBox() {
  return (
    <div className="ShopInfoBox-container">
      <span>코룡붕어빵빵</span>
      <span>09:00 ~ 18:00</span>
    </div>
  );
}
